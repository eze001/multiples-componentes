<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <MiLista msg="Juegos de video que me gustan" v-bind:lista="['Starcraft', 'Conquerors', 'HearthStone', 'Lord of Destruction', 'Starcraft 2']"/>
	<MiLista msg="Musicos y grupos de música que me gustan" v-bind:lista="['Evan Craft', 'Marcela Gandara', 'Pablo Olivares', 'Edgar Lira', 'Boanerges']"/>
  </div>
</template>

<script>
import MiLista from './components/MiLista.vue'

export default {
  name: 'App',
  components: {
    MiLista
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
